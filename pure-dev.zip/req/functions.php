<?php
error_reporting (E_ALL ^ E_NOTICE);
error_reporting(E_ERROR | E_PARSE);
$oldmask = umask(0);

//directory location
function dirloc(PDO $conn, $r) {
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$usersalt = $r['usalt'];
$result = $conn->prepare("SELECT setting FROM core_options WHERE options='directory'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$dirlocf = $r['setting']."/".$usersalt;
return $dirlocf;
}

//upload files
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$usersalt = $r['usalt'];

$result = $conn->prepare("SELECT setting FROM core_options WHERE options='directory'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

$dirlocf = $r['setting']."/".$usersalt;
$current = substr($_GET['id'], 0, -6);

$result = $conn->prepare("SELECT setting FROM core_options WHERE options='uploadSize'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$maxsize = $r['setting'].'000000';

if(isset($_FILES['myFiles'])){
$errors= array();
$file_name = $_FILES['myFiles']['name'];
$file_size =$_FILES['myFiles']['size'];
$file_tmp =$_FILES['myFiles']['tmp_name'];
$file_type=$_FILES['myFiles']['type'];
$file_ext=strtolower(end(explode('.',$_FILES['myFiles']['name'])));
      
if($file_size > $maxsize){
$errors= '<div class="errors">'.format($maxsize).' Max file size </div>';
}

$supported = array("jpeg","jpg","png");
$result = $conn->prepare("SELECT setting FROM core_options WHERE options = 'supported'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$supported = array_merge($supported, array_map('trim', explode(",", $r['setting'])));

if($r['setting'] != '') {
if(in_array($file_ext,$supported)=== false){
$errors= '<div class="errors">File type not supported </div>';
}
}
      
require('filetypes.php');
      
if(empty($errors)==true){
move_uploaded_file($file_tmp, $dirlocf."/".$current."/".$file_name);
         
$result = $conn->prepare("INSERT INTO core_files (file_name, folder_fav, user_id, dir_id, icon, file_type, file_size) VALUES ('".$file_name.'-'.salted()."','0','".$usersalt." ','".$_GET['id']."','".$file_type."','".$file_type."','".$file_size."')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
header('Location: ?id='.$_GET['id'].'');
      }else{
         //print_r($errors);
      }
   }

//make directory
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

$usalt = $r['usalt'];

$result = $conn->prepare("SELECT setting FROM core_options WHERE options='directory'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

$dirloc = $r['setting']."/".$usalt;

$foldername = substr($_GET['id'], 0, -6).'/'.str_replace(" ","_",strtolower($_POST['folder']));
//$foldername = substr($_GET['id'], 0, -6).'/'.$_POST['folder'];
if(is_dir($foldername)) {
    }  else {
    mkdir($dirloc."/".$foldername, 0777, true);
}


//$userdrive = str_replace(" ","_",strtolower($_POST['folder']));

//if($_GET['id'] == 'drives') {
//if(is_dir($userdrive)) {
//    }  else {
//    mkdir($userdrive, 0777, true);
//}
//}

//create folder
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$folderid = str_replace(" ","_",strtolower($_POST['folder']));
$folders = substr($_GET['id'], 0, -6);
if (isset($_POST['create'])){
if ($folders == substr($r['folder_name'], 0, -6)) {
//exists
}else{
$result = $conn->prepare( "INSERT INTO core_folders (folder_name, folder_fav, user_id, dir_id, icon, file_type) VALUES ('".$folderid.'-'.salted()."','0','".$r['usalt']." ','".$_GET['id']."', 'folder','Directory')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
header('Location: ?id='.$_GET['id'].'');
}
}

$main = 'drives';
if (isset($_POST['create'])){
if ($_GET['id'] == $main) {
$result = $conn->prepare( "INSERT INTO core_folders (folder_name, folder_fav, user_id, dir_id, icon, file_type) VALUES ('".$folderid.'-'.salted()."','0','".$r['usalt']." ','".$main."','folder','Directory')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
header('Location: ?id='.$main.'');
}
}

//active folder
function active(PDO $conn, $r) {
$result = $conn->prepare("SELECT folder_name FROM core_folders  WHERE folder_name='".$_GET['id']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

if ($_GET['id']  == $r['folder_name']) { 
$active = 'foldactive';
}
}


//display folders
function dispfolders(PDO $conn, $r) {
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();



echo '<ul class="side">';
$result = $conn->prepare("SELECT folder_name FROM core_folders WHERE user_id='".$r['usalt']."' ORDER BY id DESC");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {
$folderdisp = str_replace("_"," ",strtolower(substr($r['folder_name'], 0, -6)));
echo sprintf('<li class="dir">
<a href="?id='.$r['folder_name'].'" ><i id="sidi"class="fa fa-folder" aria-hidden="true"></i>'.$folderdisp.'</a></li>');
}
echo '</ul>';
}


//display favorite folders
function dispfavfolders(PDO $conn, $r) {
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

echo '<ul class="side">';
$result = $conn->prepare("SELECT folder_name FROM core_folders WHERE folder_fav='1' AND user_id='".$r['usalt']."' ORDER BY id DESC");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {
$folderdisp = str_replace("_"," ",strtolower(substr($r['folder_name'], 0, -6)));
echo sprintf('<li class="dir">
<a href="?id='.$r['folder_name'].'" ><i id="sidi"class="fa fa-folder" aria-hidden="true"></i>'.$folderdisp.'</a></li>');
}
echo '</ul>';
}

//display files
function displayfiles(PDO $conn, $r) {

$username = $_SESSION['user'];
$result = $conn->prepare("SELECT disp_type FROM core_users WHERE core_username='".$username."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$grid = $r['disp_type'];

if(array_key_exists('grid',$_POST)){
$grid = 'gridview';
}elseif(array_key_exists('list',$_POST)){
$grid = 'listview';
}

$result = $conn->prepare( "UPDATE core_users SET disp_type='$grid' WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);

if($grid == 'gridview') {
dispgrid($conn, 1);
}elseif ($grid == 'listview') {
listoptions();
displist($conn, 1);
}

}


//directory size


function dirsize($dir) {
$count_size = 0;
$count = 0;
$dir_array = scandir($dir);
foreach($dir_array as $key=>$filename){
if($filename!=".." && $filename!="."){
if(is_dir($dir."/".$filename)){
$new_foldersize = dirsize($dir."/".$filename);
$count_size = $count_size+ $new_foldersize;
}else if(is_file($dir."/".$filename)){
$count_size = $count_size + filesize($dir."/".$filename);
$count++;
}
}
}
return $count_size;
}

//format file size
function format($bytes){ 
$kb = 1024;
$mb = $kb * 1024;
$gb = $mb * 1024;
$tb = $gb * 1024;

if (($bytes >= 0) && ($bytes < $kb)) {
return $bytes . ' B';

} elseif (($bytes >= $kb) && ($bytes < $mb)) {
return ceil($bytes / $kb) . ' KB';

} elseif (($bytes >= $mb) && ($bytes < $gb)) {
return ceil($bytes / $mb) . ' MB';

} elseif (($bytes >= $gb) && ($bytes < $tb)) {
return ceil($bytes / $gb) . ' GB';

} elseif ($bytes >= $tb) {
return ceil($bytes / $tb) . ' TB';
} else {
return $bytes . ' B';
}
}

//get file icons
function geticon(PDO $conn, $r) {
$result = $conn->prepare("(SELECT file_type FROM core_files) UNION (SELECT file_type FROM core_folders)");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

}

//parent directory
function parentdir(PDO $conn, $r) {
if($_GET['id'] != 'drives') {
$result = $conn->prepare("SELECT dir_id FROM core_folders WHERE folder_name='".$_GET['id']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
echo sprintf('<div class="column" id="grida""><a href="?id='.$r['dir_id'].'" onclick="return false" ondblclick="location=this.href"><i class="fa fa-level-up" aria-hidden="true"></i> <span class="name">Parent directory</span></a></div>');
}
}

//add to favorites
function addfav(PDO $conn, $R) {
$result = $conn->prepare("SELECT dir_id FROM core_folders WHERE folder_name='".$_GET['id']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
}

//sort by
function sortby(PDO $conn, $r) {



$result = $conn->prepare("UPDATE core_users SET sort_by='".$_POST['sortby']."' WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
}

//display grid
function dispgrid(PDO $conn, $r) {
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

echo '<div id="column" class="row gridview">';
echo parentdir($conn, 1);
$result = $conn->prepare("(SELECT folder_name, icon, file_type FROM core_folders WHERE user_id='".$r['usalt']."' AND dir_id='".$_GET['id']."') UNION (SELECT file_name, icon, file_type FROM core_files WHERE user_id='".$r['usalt']."' AND dir_id='".$_GET['id']."')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {

if($r['file_type'] == 'image/jpg') {
$icons = 'fa fa-image';
}elseif($r['file_type'] == 'image/png') {
$icons = 'fa fa-image';
}elseif($r['icon'] == 'folder') {
$icons = 'fa fa-folder';
}elseif ($r['file_type'] == 'text') {
$icons = 'fa fa-file';
}elseif ($r['file_type'] == 'text/odt') {
$icons = 'fa fa-file';
}elseif ($r['file_type'] == 'archive') {
$icons = 'fa fa-archive';
}elseif ($r['file_type'] == 'application/pdf') {
$icons = 'fas fa-file-pdf';
}elseif ($r['file_type'] == 'word') {
$icons = 'fas fa-file-word';
}elseif ($r['file_type'] == 'excel') {
$icons = 'fas fa-file-excel';
}elseif ($r['file_type'] == 'other') {
$icons = 'fas fa-file';
}elseif ($r['file_type'] == 'video') {
$icons = 'fas fa-video';
}

$folderdisp = str_replace("_"," ",strtolower(substr($r['folder_name'], 0, -6)));
echo sprintf('<div class="column" id="grida""><a href="?id='.$r['folder_name'].'" onclick="return false" ondblclick="location=this.href"><i class="'.$icons.'" aria-hidden="true"></i>'.$folderdisp.'</a></div>');
}
echo '  </div>';
}

//listview options
function listoptions() {
echo ('<div class="listoptions"><button type="submit" form="delete" onclick="submit();" name="deletebtn" class="listviewbtn" ><i class="fas fa-trash-alt"></i>Delete</button>');
echo('<button type="submit" form="delete" onclick="submit();" name="move" class="listviewbtn" ><i class="fas fa-external-link-alt"></i>Move</button>');
echo('<button class="listviewbtn" ><i class="fa fa-share-alt"></i>Share</button></div>');
echo('<div id="column" class="row listview"><div class="column-top" id="grida""><span class="otherwideleft"></span><span class="name">Name</span><span class="date">Date</span><span class="otherwide">File type</span><span class="other"></span><span class="otherwide">Size</span></div>');
echo('<form id="delete" method="post">');
}

//thumbtype
function thumbs(PDO $conn, $r, $thumbtype) {
$result = $conn->prepare("SELECT setting FROM core_options WHERE options = 'icontype'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

$thumbtype = $r['setting'];

return $thumbtype;
}

//display list
function displist(PDO $conn, $r) {
$result = $conn->prepare("SELECT usalt FROM core_users WHERE core_username='".$_SESSION['user']."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();


echo parentdir($conn, 1);
$result = $conn->prepare("(SELECT folder_name, reg_date, icon, file_type, folder_fav, file_size FROM core_folders WHERE user_id='".$r['usalt']."' AND dir_id='".$_GET['id']."' ORDER BY '".$sorted."' 'DESC') UNION (SELECT file_name, reg_date, icon, file_type, folder_fav, file_size FROM core_files WHERE user_id='".$r['usalt']."' AND dir_id='".$_GET['id']."' ORDER BY '".$sorted."' 'DESC')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {

//echo'<div id="column" class="row listview">';


if($r['file_type'] == 'image/jpg') {
$icons = 'fa fa-image';
}elseif($r['file_type'] == 'image/png') {
$icons = 'fa fa-image';
}elseif($r['icon'] == 'folder') {
$icons = 'fa fa-folder';
}elseif ($r['file_type'] == 'text') {
$icons = 'fa fa-file';
}elseif ($r['file_type'] == 'text/odt') {
$icons = 'fa fa-file';
}elseif ($r['file_type'] == 'archive') {
$icons = 'fa fa-archive';
}elseif ($r['file_type'] == 'application/pdf') {
$icons = 'fas fa-file-pdf';
}elseif ($r['file_type'] == 'word') {
$icons = 'fas fa-file-word';
}elseif ($r['file_type'] == 'excel') {
$icons = 'fas fa-file-excel';
}elseif ($r['file_type'] == 'other') {
$icons = 'fas fa-file';
}elseif ($r['file_type'] == 'video') {
$icons = 'fas fa-video';
}

if ($r['folder_fav'] == 1) {
$faved = 'favbtnactive';
}else {
$faved = 'favbtn';
}


if($_GET['id'] == 'drives') {
$loc ='';
}else {
$loc =substr($_GET['id'], 0, -6).'/';
}

$url = substr(dirloc($conn, 1).'/'.$loc.$r['folder_name'], 0, -6);

if($r['icon'] != 'folder') {
$download = '<a href="'.$url.'" class="detbtn" download><i class="fa fa-download"></i><span>Download</span></a>';
}

$foldname = $r['folder_name'];
$folderdisp = str_replace("_"," ",strtolower(substr($r['folder_name'], 0, -6)));
$foldersize = format(dirsize(substr(dirloc($conn, 1).'/'.$r['folder_name'], 0, -6)));
$filesize = format($r['file_size']);
$current = substr($_GET['id'], 0, -6);
$img = substr(dirloc($conn, 1).'/'.$current.'/'.$r['folder_name'], 0, -6);

if(is_dir(substr(dirloc($conn, 1).'/'.$r['folder_name'], 0, -6))) {
$size = $foldersize;
$dirload = "'folders?id=" .$r['folder_name']. "';";
}else{
$size = $filesize;
$dirload = "'#';";
}

$thumbs = thumbs($conn, 1, $thumbtype);

if ($thumbs == 'Icons') {
$thumbnails = '<i class="'.$icons.'" aria-hidden="true"></i>';
}else if($thumbs == 'Thumbnails') {

if($r['file_type'] == 'image/png') {
$thumbnails = '<img src="'.$img.'"  style=" max-width:48px; max-height:48px; width: auto; height: 100%; float:left; margin:auto;" />';
}else if($r['file_type'] == 'image/jpg') {
$thumbnails = '<img src="'.$img.'"  style="max-width:48px; max-height:48px; width: auto; height: 100%; float:left; margin:auto;" />';
}else if($r['file_type'] == 'image/jpeg') {
$thumbnails = '<img src="'.$img.'"  style="max-width:48px; max-height:48px; width: auto; height: 100%; float:left; margin:auto;" />';
}else{
$thumbnails = '<i class="'.$icons.'" aria-hidden="true"></i>';
}
}

echo ('<div class="column" id="grida" ondblclick="window.location.href='.$dirload.'">');
echo ('<input type="checkbox" value ="'.$r['folder_name'].'" name="selected[]" onclick="selected();" class="deletebox"/>');
echo ('<button onclick="return false" ondblclick="window.location.href='.$dirload.'" class="foldlinks">');
echo ('<button type="submit" id="'.$r['folder_name'].'" class="'.$faved.'" name="fav" ><i class="fa fa-star"></i></button>');
echo ($thumbnails.'<input type="text" class="filename" placeholder="'.$folderdisp.'" id="'.$folderdisp.'" size="" onload="resizeInput();" readonly>');
echo ('<span class="date">'.substr($r['reg_date'], 0, -8).'</span>');
echo ('<span class="otherwide">'.$r['file_type'].'</span>');
echo ('<div class="detailsdown">

<button class="listbtn"><i class="fa fa-ellipsis-h"></i></button>

<div class="details-content"><button class="detbtn"><i class="fa fa-share-alt"></i><span>Share</span></button><button type="submit" name="detbtn" class="detbtn" form="details" id="'.$r['folder_name'].'" onclick="infoBar()"><i class="fa fa-info"></i><span>Details</span></button><button class="detbtn" onclick="renamefile()"><i class="fas fa-font"></i><span>Rename</span></button>'.$download.'</div>
</div>');
echo ('<span class="otherwide">'.$size.'</span></button></div>');

}
echo '</form></div>';

if(isset($_POST['fav'])) {
//$result = $conn->prepare("UPDATE core_folders SET folder_fav='1' WHERE user_id='".$r['usalt']."' AND folder_name='".$foldname."'");
//$result->execute();
//$result->setFetchMode(PDO::FETCH_ASSOC);
echo $foldname;
}

}

//share
function share() {
$result = $conn->prepare("UPDATE user_id SET subject = CONCAT( subject, '".$shared."') WHERE folder_name='".$folderdisp."' ");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
}

//addfav
function getfav() {
$addfav = '1';
if(isset($_POST['fav'])) {
header("Location: settings");
}
}

//delete
if (isset($_POST['deletebtn'])) {

$delete = $_POST['selected'];

foreach($delete as $check) {
$result = $conn->prepare("DELETE FROM core_folders WHERE folder_name =".$check."");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
}

}


//move files
if (isset($_POST['move'])) {
$checkbox = $_POST['selected'];
$delete = $checkbox[$a];
rename(newDirLoc);
}

//display details
function displaydet(PDO $conn, $r) {
if (isset($_POST['detbtn'])) {
$info = $detname;
}

$info = 'foo-etfH9';

$result = $conn->prepare("(SELECT folder_name, reg_date, icon, file_type, folder_fav FROM core_folders WHERE folder_name = '".$info."')");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

echo '<div class="filecont"><span>Name</span>'.$r['folder_name'].'<br />
<span>Type</span>'.$r['file_type'].'<br />
<span>Size</span>'.format(dirsize(substr($r['folder_name'], 0, -6))).'<br />
<span>Owner</span>'.$r['folder_name'].'<br />
<span>Date created</span>'.$r['reg_date'].'<br />
</div>';
}

//display users
function dispusers(PDO $conn, $r) {
echo '<ul class="side">';
$result = $conn->prepare("SELECT usalt, core_username FROM core_users ORDER BY id ASC");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {
echo sprintf('<li class="dir">
<a href="updateuser?id='.$r['usalt'].'"><i class="fa fa-user"></i>'.$r['core_username'].'</a></li>');   
}
echo '</ul>';
}

//display plugins
function dispplugins(PDO $conn, $r) {
echo '<ul class="side">';
$result = $conn->prepare("SELECT core_username FROM core_users ORDER BY id ASC");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
while ($r = $result->fetch()) {
echo sprintf('<li class="dir">
<a href=""><i class="fa fa-plug"></i>'.$r['core_username'].'</a></li>');   
}
echo '</ul>';
}

//extra salts
    function salted($length = 5) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;  
}

//logout
function loggedin() {
if ($_SESSION['timeout'] + 1 * 60 < time()) {
     // session timed out
session_unset();
session_destroy();
header("Location: ../login"); //die();
}
}

//restricted access
function restrict(PDO $conn, $r, $admin, $username) {
$username = $_SESSION['user'];
$result = $conn->prepare("SELECT user_type, usalt FROM core_users WHERE core_username='".$username."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$admin = $r['user_type'];
$usersalt = $r['usalt'];
if($admin != 'Administrator') {
if($_GET['id'] != $usersalt) {
header("Location: ../drive/restrict");
}
}
}

//restricted links
function restrictlink(PDO $conn, $r, $admin, $username) {
$username = $_SESSION['user'];
$result = $conn->prepare("SELECT user_type, usalt FROM core_users WHERE core_username='".$username."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$admin = $r['user_type'];
$usersalt = $r['usalt'];
if($admin != 'Administrator') {
echo 'style="display:none;"';
}
}

//restricted form
function restrictform(PDO $conn, $r, $admin, $username) {
$username = $_SESSION['user'];
$result = $conn->prepare("SELECT user_type, usalt FROM core_users WHERE core_username='".$username."'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();
$admin = $r['user_type'];
$usersalt = $r['usalt'];
if($admin != 'Administrator') {
echo 'disabled';
}
} 

//openssl encryption 
//$source = encryption source $echoed = decrypted content
function encrypt(PDO $conn, $r, $source) {
$result = $conn->prepare("SELECT setting FROM core_options WHERE options = 'enableEncryption'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

if($r['setting'] == 'Enable') {

$result = $conn->prepare("SELECT setting FROM core_options WHERE options = 'enctype'");
$result->execute();
$result->setFetchMode(PDO::FETCH_ASSOC);
$r = $result->fetch();

if( $r['setting'] == 'AES-256-CBC'){
$enctype = 'AES-256-CBC';
}elseif($r['setting'] == 'AES-128-CBC'){
$enctype = 'AES-128-CBC';
}

$ivlen = openssl_cipher_iv_length($cipher= $enctype);
$iv = openssl_random_pseudo_bytes($ivlen);
$ciphertext_raw = openssl_encrypt($source, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
$hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
$ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );

$c = base64_decode($ciphertext);
$ivlen = openssl_cipher_iv_length($cipher= $enctype);
$iv = substr($c, 0, $ivlen);
$hmac = substr($c, $ivlen, $sha2len=32);
$ciphertext_raw = substr($c, $ivlen+$sha2len);
$output = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
$calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
if (hash_equals($hmac, $calcmac))//PHP 5.6+ timing attack safe comparison
{
echo $output;
}
}else {
echo $source;
}
}

//supported file types 
function supported(){
$types = json_encode($support);
}

?>

