<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>Drive</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link rel="stylesheet" href="../req/icons/css/font-awesome.min.css">
<link rel="stylesheet" href="../req/css/styles.css">
<link rel="stylesheet" href="icons/css/font-awesome.min.css">
<link rel="stylesheet" href="css/styles.css">
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="../req/js/jquery-3.4.1.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.0.min.js"></script>
<script src="../req/js/functions.js"></script>
</head>

<body oncontextmenu="return false;">

<?php
require 'config.php';
require 'functions.php';
?>

<div id="topbar">
<?php include 'bar.php'; ?>
</div>

<div id="tabs"> <!--tabs-->
<ul id="tabbed">
<li class="<?php echo $users; ?>" <?php restrictlink( $conn, 1, $r, $admin, $username); ?>><a href="../drive/users"><i class="fa fa-users"></i>
<li class="<?php echo $folds; ?>"><a href="../drive/folders?id=drives"><i class="fa fa-folder"></i>
<li class="<?php echo $favorites; ?>"><a href="../drive/favorites"><i class="fa fa-star"></i></a></li>
<li class="<?php echo $settings; ?>" <?php restrictlink( $conn, 1, $r, $admin, $username); ?>><a href="../drive/settings"><i class="fa fa-cog"></i></a></li>
<li class="<?php echo $plugins; ?>" <?php restrictlink( $conn, 1, $r, $admin, $username); ?>><a href="../drive/plugins"><i class="fa fa-plus-square"></i></a></li>
<li class="<?php echo $calendar; ?>"><a href="../drive/folders"><i class="fa fa-calendar"></i></a></li>
</a></li>
</ul>
</div> <!--tabs-->

<div class="main"> <!--container-->


