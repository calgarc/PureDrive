<?php

/*

UI functions
--------------------------------------

1. UI functions
  1.1 h3();
  1.2 h2()
  1.3 label()
  1.4 submitBtn()
  1.5 button()
  1.6 inputText()
  1.7 inputOption()
  1.8 sideLink()
  1.9 accordion()

--------------------------------------

*/

//Required files
if(!defined('inc')) {
   die();
}


/*

1 UI functions

*/

class ui {

    public $data;

    //h3 tag
    public function h3($conn, $data) {

        $r = 1;
        $data = secure($conn, $data);

        if('true' == auth($conn, 1)) {
            echo('<h3>'.$data.'</h3>');
        }
    }

    //h3 tag
    public function h2($conn, $data) {

        $r = 1;
        $data = secure($conn, $data);

        if('true' == auth($conn, 1)) {
            echo('<h2>'.$data.'</h2>');
        }
    }

    //label
    public function label($conn, $data) {

        $r = 1;
        $data = secure($conn, $data);

        if('true' == auth($conn, 1)) {
            echo('<label>'.$data.'</label>');
        }
    }

    //submit button
    public function submitBtn($conn, $value, $class, $name) {

        $r = 1;
        $value = secure($conn, $value);
        $class = secure($conn, $class);
        $name = secure($conn, $name);

        if('true' == auth($conn, 1)) {
            echo('<input type="submit" class="'.$class.'" value="'.$value.'" name="'.$name.'">');
        }
    }

    //red button
    public function button($conn, $value, $class, $name, $type) {

        $r = 1;
        $value = secure($conn, $value);
        $class = secure($conn, $class);
        $name = secure($conn, $name);
        $type = secure($conn, $type);

        if('true' == auth($conn, 1)) {
            echo('<button type="'.$type.'" class="'.$class.'" name="'.$name.'" value="'.$value.'">'.$name.'</button>');
        }
    }


    //input text
    public function inputText($conn, $value, $name) {

        $r = 1;
        $value = sanitize(encrypt($conn, 1, $value));
        $name = sanitize(encrypt($conn, 1, $name));

        if('true' == auth($conn, 1)) {
            echo('<input type="text" value="'.$value.'" name="'.$name.'" id="'.$name.'">');
        }
    }

    //input opntions
    public function inputOption($conn, $value) {

        $r = 1;
        $value = secure($conn, $value);

        if('true' == auth($conn, 1)) {
            echo('<option value="'.$value.'">'.$value.'</option>');
        }
    }

    //side links
    public function sideLink($conn, $url, $name, $icon) {

        $r = 1;
        $url = secure($conn, $url);
        $name = secure($conn, $name);
        $icon = secure($conn, $icon);


        if('true' == auth($conn, 1)) {
            echo('<li class="dir"><a href="'.$url.'"><i class="'.$icon.'"></i>'.$name.'</a></li>');
        }
    }

    //accordian
    public function accordion($conn, $data, $name, $icon) {

      $r = 1;
      $data = secure($conn, $data);
      $name = secure($conn, $name);
      $icon = secure($conn, $icon);


      if('true' == auth($conn, 1)) {

        echo'<button class="accordion"><i class="'.$icon.'" aria-hidden="true"></i>'.$name.'</button>';
          echo '<div class="panel">';
              if (!ismobile()) {
                  $data;
              }
          echo '</div>';

        }
    }


}

?>
