<?php
require 'config.php';
require ('functions.php');
$phpfunc = $_POST['phpfunc'];

if($phpfunc == 0) {
share($conn, 1 );
}

if($phpfunc == 1) {
imgdisp($conn, 1);
}

if($phpfunc == 2) {
videodisp($conn, 1);
}

if($phpfunc == 3) {
displaydet($conn, 1);
}
?>
