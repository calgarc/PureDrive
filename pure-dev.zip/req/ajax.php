<?php
require 'config.php';
require ('functions.php');
$phpfunc = $_POST['phpfunc'];

if($phpfunc == 0) {
share($conn, 1 );
}

if($phpfunc == 1) {
imgdisp($conn, 1);
}

if($phpfunc == 2) {
videodisp($conn, 1);
}

if($phpfunc == 3) {
displaydet($conn, 1);
}

if($phpfunc == 4) {
audiodisp($conn, 1);
}

if($phpfunc == 5) {
$dispfav = '0';
displist($conn, 1, $dispfav);
//dispgrid($conn, 1, $dispfav);
}

if($phpfunc == 6) {
$dispfav = '0';
//displist($conn, 1, $dispfav);
dispgrid($conn, 1, $dispfav);
}

?>
