<?php
var_dump("lol");

?>
