//Selected files 
function selected() {
$( "input:checked").parent('.column').css( "background-color", "#dddddd" );
$( "input:not(:checked)").parent('.column').removeAttr( "style" );
}

function renamefile(rname) {
var input = rname.substring( 0, rname.indexOf( "-" ) );
$('.filename2').prop('readonly', true);
$('.filename2').attr("name", "");
$('.filename2').removeClass('filename2');
$('.unhide').removeClass('unhide');
document.getElementById(input + '-iname').classList.add('filename2');
document.getElementById(input + '-iname').removeAttribute('readonly');
document.getElementById(input + '-rebtn').classList.add('unhide');
document.getElementById(input + '-iname').setAttribute("name", "rename"); 
}

//auto scale file names
function resizeInput() {
    $(this).attr('size', $(this).val().length);
}

$('input[type="text"]')
    // event handler
    .keyup(resizeInput)
    // resize on page load
    .each(resizeInput);
    
function submit() {
$("#delete").submit();
}

function update() { 
$( "#right" ).load(window.location.href + " #right" );
}

//share
function popup() {
$.ajax({
type: 'post',
url: '../req/ajax',
data:"function_to_call=0",

success: function(data){
alert($(this).attr("value"));
$(".acont").html(data);
var modal = document.querySelector(".folderPopup");
modal.classList.toggle("show-modal");
}
});
}

// $.ajax({
// type: 'post',
// url: '../req/ajax',
// data:{share: share},
// 
// success: function(data){
// alert(data);
// }
// });


//lightbox
function popupc() {
$.ajax({
type: 'post',
url: '../req/ajax',
data:"function_to_call=1",

success: function(data){
//alert(data);
$(".acont").html(data);
var modal = document.querySelector(".folderPopup");
modal.classList.toggle("show-modal");
}
});
}
