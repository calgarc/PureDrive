//Selected files 
function selected() {
$( "input:checked").parent('.column').css( "background-color", "#dddddd" );
$( "input:not(:checked)" ).parent('.column').removeAttr( "style" );
}


//add to favorites
function fav(){
$('.favbtn').click(function() {
var faved = $(this).attr('id');

$.ajax({
  type:"POST",
  url:"../drive/test",
  data: { 'faved' : faved}
})
      
console.log(faved);
});
}

function renamefile() {
document.getElementById('oof').readOnly = false;
document.getElementById("oof").classList.add('filename2');
}

//auto scale file names
function resizeInput() {
    $(this).attr('size', $(this).val().length);
}

$('input[type="text"]')
    // event handler
    .keyup(resizeInput)
    // resize on page load
    .each(resizeInput);
