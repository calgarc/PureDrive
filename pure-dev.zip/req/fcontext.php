<div id='rclick'><!--context menu-->
<ul id='items'>
<li><button class="folderBut2" name="delete" id="delete"><i class="fa fa-trash"></i>Delete</button></li> 
</ul>
<hr />
<ul id="items">
<li><button class="folderBut2"><i class="fa fa-share-alt"></i>Share</button></li>
<li><button class="folderBut2"><i class="fa fa-pencil"></i>Rename</button></li>
<li><button class="trigger folderBut2"><i class="fa fa-download"></i>Download</button></li>
<li><button class="trigger folderBut2"><i class="fa fa-star"></i>Favorite</button></li>
<li><button class="folderBut2" onclick="infoBar()"><i class="fa fa-info"></i>Details</button></li>
</ul>
<hr />
<ul id="items">
<li><button class="trigger2 folderBut2"> <i class="fa fa-folder"></i>New Folder</button></li>
<li><button class="folderBut2"><i class="fa fa-file"></i>New File</button></li>
</ul>
</div>
