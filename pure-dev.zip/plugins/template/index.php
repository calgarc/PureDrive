<!--plugin header-->
<?php
define('func', TRUE);

$root = '../../';
require $root.'req/headers.php';

$searchable = 'true';
$plugin = 'active';
require $root.'req/index.php';

IsSession();
loggedin($root);
?>


<!--plugin start-->
<div class="right"><!--left-->

</div><!--left-->


<div class="right"><!--right-->

</div><!--right-->


<?php
$conn = null;
?>
</div><!--main-->
</body>
</html>
