<!--plugin header-->
<?php
define('func', TRUE);

$root = '../../';
require '../req/headers.php';

$searchable = 'true';
$plugin = 'active';
require '../req/index.php';

IsSession();
loggedin($root);
?>


<!--plugin start-->
<div id="left"><!--left-->

</div><!--left-->


<div id="right" class="right"><!--right-->

</div><!--right-->


<?php
$conn = null;
?>
</div><!--main-->


</body>
</html>
