<?php
define('func', TRUE);

$root = '../';
require '../req/headers.php';

$searchable = 'false';
$settings = 'active';
require '../req/index.php';

if(!access($conn, 'groups')) {
  header("location: restrict");
}

IsSession($root);
loggedin($root);
//restrict($conn, $admin, $username, 1);

//left
echo '<div id="left">';
    ui::h2($conn, 'Settings');

    echo '<ul class="side">';
      ui::sideLink($conn, 'settings', 'General', 'fas fa-sliders-h', '');
      ui::sideLink($conn, 'security', 'Security', 'fas fa-lock', '');
      ui::sideLink($conn, 'server', 'Server', 'fas fa-server', '');
      ui::sideLink($conn, 'groups', 'Users / Groups', 'fa fa-users', '');
    echo '</ul>';

echo '</div>';


echo '<div id="right" class="right">
  <div class="userinfo">';

    ui::h3($conn, 'Deactivated Users');

    $result = $conn->prepare("SELECT core_username, usalt FROM core_users WHERE del = '1'");
    $result->execute();
    $result->setFetchMode(PDO::FETCH_ASSOC);

    echo('<form class="form" method="post"> <label>RESTORE USERS</label><select class="btn locbtn" name="users" id="users">');

    while ($r = $result->fetch()) {
        echo("<option value='".$r['core_username']."'>".$r['core_username']."</option>");
    }

    echo'</select>';

    ui::submitBtn($conn, 'Restore Users', 'button', 'restore');
    echo '</form>';

    ui::h3($conn, 'Groups');

    echo('<form class="form" method="post">');

    ui::label($conn, 'CREATE GROUPS:');
    ui::inputText($conn, '', 'groups', 'text', 'Group Name');

    ui::submitBtn($conn, 'Create', 'button', 'create');
    echo '</form>';

    if (isset($_POST['restore'])) {
      $user = encrypt($conn, 1, $_POST['users']);
      $r = update($conn, "UPDATE core_users SET del = :del WHERE core_username= :user", [':user' => $user, ':del' => '0']);
      header("location: groups");
    }

    if (isset($_POST['create'])) {
      $groups = encrypt($conn, 1, $_POST['groups']);

      $result = $conn->prepare("INSERT INTO core_groups (groups, level) VALUES ('".$groups."', '0')");
      $result->execute();
      $result->setFetchMode(PDO::FETCH_ASSOC);

      header("location: groups");
    }


    ?>

  </div>
</div><!--right-->


<?php
$conn = null;
?>

</div><!--main-->
</body>
</html>
