<?php
require '../req/headers.php';
if(isset($_SESSION['user'])) {
//echo "Your session is running " . $_SESSION['user'];
}

if ($_SESSION['user'] == '0'){
header("Location: ../login"); //die();
}


$favorites = 'active';
require '../req/index.php';

loggedin();

?>

<div id="left"><!--left-->


</div><!--left-->



<div id="right" class="right"><!--right-->





</div><!--right-->


<?php 
$conn = null;
?> 
</div><!--main-->
</body>
</html>
