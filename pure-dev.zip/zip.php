<?php

function Zip(){
$pathdir = "drive/profile/";
$zipcreated = "test.zip";
$newzip = new ZipArchive;
if($newzip -> open($zipcreated, ZipArchive::CREATE ) === TRUE) {
$dir = opendir($pathdir);
while($file = readdir($dir)) {
if(is_file($pathdir.$file)) {
$newzip -> addFile($pathdir.$file, $file);
}
}
$newzip ->close();
}

header("Location: test.zip");
}

?>

<body>
<div>
<form class="form" id="formed" method="post"><input type="submit" name="dl" value="download" id="dl"></form>
</div>
</body>

<?php


if(isset($_POST['dl'])) {
Zip();
}
?>

