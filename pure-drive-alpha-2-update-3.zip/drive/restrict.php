<?php
define('func', TRUE);

$root = '../';
require '../req/headers.php';

header("Location: ../login"); //die();

loggedin($root);

$conn = null;
?>
</div><!--main-->
</body>
</html>
