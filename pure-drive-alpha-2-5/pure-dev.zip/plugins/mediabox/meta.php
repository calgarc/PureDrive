<?php 

//PLUGIN NAME
$plugin = 'Mediabox'; //plugin name. Folder and zip should have matching names
$info = 'A media player that plays audio from a user specified directory. Built on Wavesurfer and plays all web supported audio files'; //max 255 chars
$icon = 'logo.png'; // immage/icon name of plugin 35x35px jpg/png located in plugins root directory
$author = 'Calgar C'; //plugin author
$version = '1.0'; //plugin version
$mobile = 'true'; // plugin active on mobile true/false

?>
