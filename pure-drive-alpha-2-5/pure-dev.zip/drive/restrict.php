<?php
define('func', TRUE);

$root = '../';
require '../req/headers.php';

header("Location: ../login"); //die();

loggedin($root);
?>

<?php
$conn = null;
?>
</div><!--main-->
</body>
</html>
