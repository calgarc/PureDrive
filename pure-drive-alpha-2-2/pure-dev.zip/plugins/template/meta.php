<?php 

//PLUGIN NAME
$plugin = ''; //plugin name
$info = ''; //max 255 chars
$icon = ''; // immage/icon name of plugin 35x35px jpg/png located in plugins root directory
$author = ''; //plugin author
$version = ''; //plugin version
$mobile = ''; //plugin active on mobile true/false
?>
