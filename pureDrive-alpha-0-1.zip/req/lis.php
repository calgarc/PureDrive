

<div class="column" id="grida">
<input type="checkbox" value =".$r['folder_name']." name="selected[]" id="selected" form name="deleteform" onclick="selected();" class="deletebox"/>

<a href="?id=
.$r['folder_name'].
" onclick="return false" ondblclick="location=this.href" id="foldlinks" >

<form id="addfav" method="post">
<button type="submit" onclick="fav();" id="'.$r['folder_name'].'" class="'.$faved.'"><i class="fa fa-star"></i></button>
</form>

.$thumbnails.
<input type="text" class="filename" placeholder="
.$folderdisp.
" id="
.$folderdisp.
" size="" onload="resizeInput();" readonly>

<span class="date">
.substr($r['reg_date'], 0, -8).
</span>

<span class="otherwide">
.$r['file_type'].
</span>

<div class="detailsdown">
<button class="listbtn"><i class="fa fa-ellipsis-h"></i></button>

<div class="details-content">
<button class="detbtn"><i class="fa fa-share-alt"></i><span>Share</span></button>

<button type="submit" name="detbtn" class="detbtn" form="details" id="
.$r['folder_name'].
" onclick="infoBar()"><i class="fa fa-info"></i><span>Details</span></button>

<button class="detbtn" onclick="renamefile()"><i class="fas fa-font"></i><span>Rename</span></button>

.$download.

</div>
</div>
<span class="otherwide">
.$size.
</span></a>
</div>
